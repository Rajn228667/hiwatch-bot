"""
HiWatch Settings Bot — чистый Python, без внешних библиотек.
Использует только requests для Telegram API.
"""
import os
import json
import time
import logging
import requests

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip().strip('"').strip("'")
ADMIN_USERNAMES = [
    u.strip().lstrip("@").lower()
    for u in (os.getenv("ADMIN_USERNAMES") or "STPierce,Who_Knyaz").replace(";", ",").split(",")
    if u.strip()
]
ADMIN_CHAT_IDS = []
_DEFAULT_IDS = "1930108146,1418146556"
_raw = os.getenv("ADMIN_CHAT_IDS") or os.getenv("ADMIN_CHAT_ID") or _DEFAULT_IDS
for _id in _raw.replace(";", ",").split(","):
    _id = _id.strip()
    if _id.lstrip("-").isdigit():
        cid = int(_id)
        if cid not in ADMIN_CHAT_IDS:
            ADMIN_CHAT_IDS.append(cid)

XAI_API_KEY = os.getenv("XAI_API_KEY", "").strip()
XAI_BASE_URL = os.getenv("XAI_BASE_URL", "https://api.x.ai/v1").strip()
XAI_MODEL = os.getenv("XAI_MODEL") or os.getenv("XAI_MODEL_NAME") or "grok-3-mini"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("bot")

API = f"https://api.telegram.org/bot{BOT_TOKEN}"

# ─── TELEGRAM API CALLS ──────────────────────────────

def tg(method, **params):
    try:
        r = requests.post(f"{API}/{method}", json=params, timeout=30)
        return r.json()
    except Exception as e:
        log.error(f"tg {method} error: {e}")
        return {}

def send_msg(chat_id, text, reply_markup=None):
    params = {"chat_id": chat_id, "text": text, "parse_mode": "HTML", "disable_web_page_preview": True}
    if reply_markup:
        params["reply_markup"] = json.dumps(reply_markup)
    return tg("sendMessage", **params)

def answer_cb(cb_id, text=None):
    params = {"callback_query_id": cb_id}
    if text:
        params["text"] = text
    return tg("answerCallbackQuery", **params)

# ─── KEYBOARDS (dict format) ─────────────────────────

def client_menu():
    return {
        "resize_keyboard": True, "is_persistent": True,
        "keyboard": [
            [{"text": "\U0001f7e9\U0001f7e2 Оставить заявку"}, {"text": "\U0001f7e6\U0001f535 Цены и услуги"}],
            [{"text": "\U0001f7e8\U0001f7e1 Офис и контакты"}, {"text": "\U0001f7ea\U0001f7a3 Спросить ИИ"}],
            [{"text": "\U00002b1c\u26aa Помощь"}],
        ]
    }

def admin_menu():
    return {
        "resize_keyboard": True, "is_persistent": True,
        "keyboard": [
            [{"text": "\U0001f7e6\U0001f535 Цены и услуги"}, {"text": "\U0001f7e8\U0001f7e1 Офис и контакты"}],
            [{"text": "\U0001f7ea\U0001f7a3 Спросить ИИ"}, {"text": "\U00002b1c\u269b\ufe0f Статус бота"}],
            [{"text": "\U00002b1c\u26aa Помощь"}],
        ]
    }

def cancel_kb():
    return {"resize_keyboard": True, "one_time_keyboard": True, "keyboard": [[{"text": "\U0001f7e5\U0001f534 Отмена"}]]}

def remove_kb():
    return {"remove_keyboard": True}

def after_order_kb():
    return {"inline_keyboard": [
        [{"text": "\U0001f7e9\U0001f7e2 Новая заявка", "callback_data": "order:start"}],
        [{"text": "\U0001f7ea\U0001f7a3 Спросить ИИ", "callback_data": "ask:more"}],
        [{"text": "\U0001f7e6\U0001f535 Цены", "callback_data": "info:prices"}],
    ]}

# ─── MESSAGES ────────────────────────────────────────

WELCOME_CLIENT = (
    "<b>\U0001f6e1\ufe0f HiWatch Settings Bot</b>\n\n"
    "Привет! Я помогу с настройкой ПК, сборкой, видеонаблюдением.\n\n"
    "<b>Что я умею:</b>\n"
    "\U0001f7e9 — оставить заявку (менеджер свяжется с вами)\n"
    "\U0001f7e6 — цены и услуги\n"
    "\U0001f7e8 — офис и контакты\n"
    "\U0001f7ea — спросить ИИ (Пирс) про ПК\n\n"
    "Нажми кнопку ниже \U0001f447"
)

WELCOME_ADMIN = (
    "<b>\U0001f6e1\ufe0f HiWatch Settings Bot</b>\n\n"
    "Привет, <b>админ</b>! \u2705\n"
    "Вы вошли как менеджер — заявки от клиентов будут приходить вам в ЛС.\n\n"
    "<b>Доступно:</b>\n"
    "\U0001f7e6 — цены и услуги\n"
    "\U0001f7e8 — офис и контакты\n"
    "\U0001f7ea — спросить ИИ (Пирс)\n"
    "\u269b\ufe0f — статус бота\n\n"
    "<i>Админы не могут отправлять заявки — только клиенты.</i>"
)

PRICES_TEXT = (
    "<b>\U0001f4b0 Цены и услуги</b>\n\n"
    "<b>\U0001f4bb Настройка ПК</b> — 5 000 – 15 000 \u20b8\n"
    "Установка Windows, драйверов, программ, оптимизация\n\n"
    "<b>\U0001f527 Сборка / апгрейд</b> — 8 000 – 15 000 \u20b8\n"
    "Подбор комплектующих, сборка, тестирование\n\n"
    "<b>\U0001f4cf ПК + видеонаблюдение</b> — 10 000 – 15 000 \u20b8\n"
    "Настройка камер, регистраторов, удалённый доступ\n\n"
    "<b>\U0001f4ac Консультация</b> — бесплатно\n"
    "Помощь с выбором, диагностика проблемы\n\n"
    "<i>Финальная цена зависит от сложности — менеджер обсудит с вами</i>"
)

OFFICE_TEXT = (
    "<b>\U0001f4cd Офис и контакты</b>\n\n"
    "\U0001f3e2 <b>Адрес:</b> Шымкент, ул. Тауке Хана 143\n\n"
    "\U0001f4de <b>Телефоны:</b>\n"
    "   \U0001f7e6 +7 777 187 17 17\n"
    "   \U0001f7e6 +7 708 001 12 12\n"
    "   \U0001f7e9 +7 705 133 68 01 <i>(напрямую с работником)</i>\n\n"
    "\U0001f310 <b>Сайт:</b> hikmart.kz\n\n"
    "Режим: Пн–Сб, 10:00 – 20:00"
)

HELP_TEXT = (
    "<b>\u2139\ufe0f Помощь</b>\n\n"
    "\U0001f7e9 <b>Оставить заявку</b> — опиши проблему, менеджер свяжется\n"
    "\U0001f7e6 <b>Цены и услуги</b> — прайс-лист\n"
    "\U0001f7e8 <b>Офис и контакты</b> — адрес, телефон\n"
    "\U0001f7ea <b>Спросить ИИ</b> — задай вопрос про ПК\n\n"
    "Команды: /start, /order, /help"
)

ADMIN_STATUS = (
    "<b>\u269b\ufe0f Статус бота</b>\n\n"
    f"\U0001f7e9 <b>Бот:</b> онлайн\n"
    f"\U0001f465 <b>Админы:</b> {', '.join('@' + u for u in ADMIN_USERNAMES)}\n"
    f"\U0001f4de <b>Chat IDs:</b> {', '.join(str(c) for c in ADMIN_CHAT_IDS)}\n"
    f"\U0001f9e0 <b>ИИ Пирс:</b> {'активен' if XAI_API_KEY else 'не настроен'}\n"
    f"\U0001f4c0 <b>Режим:</b> polling"
)

ORDER_NAME = "<b>\U0001f7e9\U0001f7e2 Заявка — шаг 1/3</b>\n\nВведи своё <b>имя</b>:\n<i>(например: Алексей)</i>"
ORDER_PHONE = "<b>\U0001f7e9\U0001f7e2 Заявка — шаг 2/3</b>\n\nВведи свой <b>номер телефона</b>:\n<i>(например: +7 700 123 45 67)</i>"
ORDER_PROBLEM = "<b>\U0001f7e9\U0001f7e2 Заявка — шаг 3/3</b>\n\nОпиши <b>проблему с ПК</b>:\n<i>(например: ПК тормозит, нужно переустановить Windows)</i>"
ORDER_DONE = "<b>\u2705 Заявка принята!</b>\n\nМенеджер свяжется с вами в ближайшее время.\nОбсудим цену, адрес и удобное время.\n\nСпасибо! \U0001f64f"
ORDER_CANCEL = "\U0001f534 Заявка отменена. Можно начать заново в любой момент."
ADMIN_BLOCKED = "\u26d4 <b>Вы админ!</b>\n\nАдмины не могут отправлять заявки.\nЗаявки отправляют клиенты — вам они приходят в ЛС."

# ─── STATE ───────────────────────────────────────────

USER_STATE = {}

def set_state(cid, step, **extra):
    s = USER_STATE.get(cid, {})
    s["step"] = step
    s.update(extra)
    USER_STATE[cid] = s

def get_state(cid):
    return USER_STATE.get(cid, {})

def clear_state(cid):
    USER_STATE.pop(cid, None)

def is_admin(user):
    if not user:
        return False
    if user.get("username", "").lower() in ADMIN_USERNAMES:
        return True
    if user.get("id") in ADMIN_CHAT_IDS:
        return True
    return False

# ─── ADMIN NOTIFY ────────────────────────────────────

def notify_admins(text):
    for cid in ADMIN_CHAT_IDS:
        send_msg(cid, text)
        log.info(f"Order sent to admin {cid}")

def now_str():
    from datetime import datetime, timezone, timedelta
    return datetime.now(timezone(timedelta(hours=6))).strftime("%d.%m.%Y %H:%M")

def build_order_msg(user, state):
    name = state.get("name", "—")
    phone = state.get("phone", "—")
    problem = state.get("problem", "—")
    uname = f"@{user['username']}" if user.get("username") else "нет"
    full = user.get("first_name", "") + " " + user.get("last_name", "")
    full = full.strip() or "—"
    return (
        "<b>\U0001f7e9\U0001f7e2 НОВАЯ ЗАЯВКА</b>\n"
        "\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n\n"
        f"<b>\U0001f464 Имя:</b> {name}\n"
        f"<b>\U0001f4de Телефон:</b> {phone}\n"
        f"<b>\U0001f4bb Проблема:</b> {problem}\n\n"
        f"<b>Telegram:</b> {uname}\n"
        f"<b>Имя в TG:</b> {full}\n"
        f"<b>ID:</b> <code>{user['id']}</code>\n\n"
        f"<b>\u23f1 Время:</b> {now_str()}\n"
        "\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501"
    )

# ─── AI ──────────────────────────────────────────────

CHAT_HISTORY = {}

def fast_reply(text):
    t = text.lower()
    if any(w in t for w in ["привет", "hello", "hi", "салам"]):
        return "Привет! Я Пирс — ИИ-ассистент. Спроси про ПК! \U0001f7a3"
    if any(w in t for w in ["цена", "цен", "сколько", "прайс"]):
        return PRICES_TEXT
    if any(w in t for w in ["адрес", "офис", "где", "контакт", "телефон"]):
        return OFFICE_TEXT
    if any(w in t for w in ["ssd", "диск"]) and any(w in t for w in ["какой", "что", "посовет"]):
        return ("\U0001f7ea\U0001f7a3 <b>SSD — рекомендации:</b>\n\n"
                "\U0001f7e9 Samsung 870 EVO — топ для надёжности\n"
                "\U0001f7e6 Kingston KC3000 — лучшее цена/скорость\n"
                "\U0001f7e8 WD Blue SN570 — бюджетный NVMe\n\n"
                "SATA: для старых ПК. NVMe: для новых (в 5 раз быстрее).")
    if any(w in t for w in ["windows", "винда", "переустано"]):
        return ("\U0001f7ea\U0001f7a3 <b>Переустановка Windows:</b>\n\n"
                "1. Сохранить файлы\n2. Создать флешку (Rufus)\n"
                "3. Загрузиться с флешки\n4. Установить Windows\n5. Драйверы\n\n"
                "Цена: 5 000 – 10 000 \u20b8. Нажми \U0001f7e9 «Оставить заявку»!")
    if any(w in t for w in ["тормозит", "медленн", "лагает", "глючит"]):
        return ("\U0001f7ea\U0001f7a3 <b>ПК тормозит:</b>\n\n"
                "1. Проверить диск (CrystalDiskInfo)\n2. Очистить автозагрузку\n"
                "3. Проверить температуру\n4. Очистить от пыли\n5. Добавить RAM/SSD\n\n"
                "Не помогает? Нажми \U0001f7e9 «Оставить заявку»!")
    return None

def grok_reply(user_id, question):
    history = CHAT_HISTORY.get(user_id, [])
    history.append({"role": "user", "content": question})
    history = history[-6:]
    CHAT_HISTORY[user_id] = history
    system = ("Ты — Пирс, ИИ-ассистент HiWatch Settings (Шымкент, ул. Тауке Хана 143). "
              "Отвечай кратко на русском. Телефоны: +77771871717, +77080011212, +77051336801.")
    r = requests.post(
        f"{XAI_BASE_URL}/chat/completions",
        headers={"Authorization": f"Bearer {XAI_API_KEY}"},
        json={"model": XAI_MODEL, "messages": [{"role": "system", "content": system}] + history, "max_tokens": 400, "temperature": 0.7},
        timeout=15,
    )
    r.raise_for_status()
    answer = r.json()["choices"][0]["message"]["content"]
    history.append({"role": "assistant", "content": answer})
    CHAT_HISTORY[user_id] = history[-6:]
    return answer

# ─── HANDLERS ────────────────────────────────────────

def handle_message(msg):
    chat_id = msg["chat"]["id"]
    user = msg.get("from", {})
    text = msg.get("text", "")
    adm = is_admin(user)
    state = get_state(user.get("id", 0))

    # Commands
    if text.startswith("/start"):
        if adm:
            if user["id"] not in ADMIN_CHAT_IDS:
                ADMIN_CHAT_IDS.append(user["id"])
                log.info(f"Admin bound: @{user.get('username')} -> {user['id']}")
            clear_state(user["id"])
            send_msg(chat_id, WELCOME_ADMIN, admin_menu())
        else:
            clear_state(user["id"])
            send_msg(chat_id, WELCOME_CLIENT, client_menu())
        return

    if text.startswith("/setadmin"):
        if not (user.get("username", "").lower() in ADMIN_USERNAMES):
            send_msg(chat_id, "\u26d4 Только для менеджеров.")
            return
        cid = user["id"]
        if cid not in ADMIN_CHAT_IDS:
            ADMIN_CHAT_IDS.append(cid)
        clear_state(user["id"])
        send_msg(chat_id, f"\u2705 Вы админ!\n<code>chat_id: {cid}</code>", admin_menu())
        return

    if text.startswith("/order"):
        if adm:
            send_msg(chat_id, ADMIN_BLOCKED, admin_menu())
            return
        set_state(user["id"], "name")
        send_msg(chat_id, ORDER_NAME, cancel_kb())
        return

    if text.startswith("/help"):
        send_msg(chat_id, HELP_TEXT, admin_menu() if adm else client_menu())
        return

    if text.startswith("/cancel"):
        clear_state(user["id"])
        send_msg(chat_id, ORDER_CANCEL, admin_menu() if adm else client_menu())
        return

    if text.startswith("/id"):
        t = f"Ваш chat_id: <code>{user['id']}</code>"
        if user.get("username"):
            t += f"\nUsername: @{user['username']}"
        if adm:
            t += "\n\U0001f7e9 Статус: админ"
        send_msg(chat_id, t)
        return

    # State flow
    if state.get("step"):
        step = state["step"]

        if "Отмена" in text:
            clear_state(user["id"])
            send_msg(chat_id, ORDER_CANCEL, admin_menu() if adm else client_menu())
            return

        if step == "ai_chat":
            local = fast_reply(text)
            if local:
                clear_state(user["id"])
                send_msg(chat_id, local, admin_menu() if adm else client_menu())
                return
            if XAI_API_KEY:
                try:
                    reply = grok_reply(user["id"], text)
                    clear_state(user["id"])
                    send_msg(chat_id, reply, admin_menu() if adm else client_menu())
                    return
                except Exception as e:
                    log.warning(f"Grok error: {e}")
            clear_state(user["id"])
            send_msg(chat_id, "\U0001f7a3 Не могу ответить. Нажми \U0001f7e9 «Оставить заявку» — менеджер поможет!",
                     admin_menu() if adm else client_menu())
            return

        if adm:
            clear_state(user["id"])
            send_msg(chat_id, ADMIN_BLOCKED, admin_menu())
            return

        if step == "name":
            if len(text) < 2:
                send_msg(chat_id, "\u274c Имя слишком короткое. Ещё раз:")
                return
            set_state(user["id"], "phone", name=text)
            send_msg(chat_id, ORDER_PHONE)
            return

        if step == "phone":
            digits = "".join(c for c in text if c.isdigit())
            if len(digits) < 7:
                send_msg(chat_id, "\u274c Неверный номер. Ещё раз:\n<i>(+7 700 123 45 67)</i>")
                return
            set_state(user["id"], "problem", name=state.get("name", ""), phone=text)
            send_msg(chat_id, ORDER_PROBLEM)
            return

        if step == "problem":
            if len(text) < 3:
                send_msg(chat_id, "\u274c Опиши подробнее (мин 3 символа):")
                return
            state["problem"] = text
            notify_admins(build_order_msg(user, state))
            send_msg(chat_id, ORDER_DONE, after_order_kb())
            clear_state(user["id"])
            return

    # Menu buttons
    if "Оставить заявку" in text and adm:
        send_msg(chat_id, ADMIN_BLOCKED, admin_menu())
    elif "Оставить заявку" in text:
        set_state(user["id"], "name")
        send_msg(chat_id, ORDER_NAME, cancel_kb())
    elif "Цены" in text or "услуги" in text:
        send_msg(chat_id, PRICES_TEXT, admin_menu() if adm else client_menu())
    elif "Офис" in text or "контакты" in text:
        send_msg(chat_id, OFFICE_TEXT, admin_menu() if adm else client_menu())
    elif "Спросить" in text or "ИИ" in text:
        send_msg(chat_id, "\U0001f7a3 <b>Спроси Пирса</b>\n\nНапиши вопрос про ПК:", remove_kb())
        set_state(user["id"], "ai_chat")
    elif "Статус" in text and adm:
        send_msg(chat_id, ADMIN_STATUS, admin_menu())
    elif "Помощь" in text:
        send_msg(chat_id, HELP_TEXT, admin_menu() if adm else client_menu())
    elif "Отмена" in text:
        clear_state(user["id"])
        send_msg(chat_id, ORDER_CANCEL, admin_menu() if adm else client_menu())
    else:
        send_msg(chat_id, "Выбери кнопку \U0001f447", admin_menu() if adm else client_menu())


def handle_callback(cb):
    user = cb.get("from", {})
    adm = is_admin(user)
    chat_id = cb["message"]["chat"]["id"]
    data = cb.get("data", "")

    if data == "order:start":
        if adm:
            send_msg(chat_id, ADMIN_BLOCKED, admin_menu())
        else:
            set_state(user["id"], "name")
            send_msg(chat_id, ORDER_NAME, cancel_kb())
    elif data == "ask:more":
        set_state(user["id"], "ai_chat")
        send_msg(chat_id, "\U0001f7a3 Напиши вопрос про ПК:", remove_kb())
    elif data == "info:prices":
        send_msg(chat_id, PRICES_TEXT, admin_menu() if adm else client_menu())
    elif data == "info:office":
        send_msg(chat_id, OFFICE_TEXT, admin_menu() if adm else client_menu())

    answer_cb(cb["id"])

# ─── POLLING LOOP ────────────────────────────────────

def main():
    if not BOT_TOKEN:
        print("ERROR: BOT_TOKEN is not set!")
        return

    log.info(f"Admins: {ADMIN_USERNAMES} (chat_ids: {ADMIN_CHAT_IDS})")

    # Delete webhook, switch to polling
    tg("deleteWebhook")
    me = tg("getMe")
    if me.get("ok"):
        log.info(f"Bot: @{me['result']['username']}")

    log.info("Starting polling...")
    offset = 0

    while True:
        try:
            updates = tg("getUpdates", offset=offset, timeout=30)
            if not updates.get("ok"):
                time.sleep(5)
                continue

            for upd in updates.get("result", []):
                offset = upd["update_id"] + 1

                if "message" in upd:
                    handle_message(upd["message"])
                elif "callback_query" in upd:
                    handle_callback(upd["callback_query"])

        except KeyboardInterrupt:
            log.info("Stopped")
            break
        except Exception as e:
            log.error(f"Polling error: {e}")
            time.sleep(3)


if __name__ == "__main__":
    main()
